﻿namespace Plims.Models
{
    public class ProductionTransactionAdjust
    {

    }
}
