﻿namespace Plims.Models
{
    public class TableDataRow
    {
    
            public string Section { get; set; }
            public string Service { get; set; }

    }
}
