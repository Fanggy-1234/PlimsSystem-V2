﻿namespace Plims.Models
{
	public class ResultGrpGradeModel
	{
		public string Grade { get; set; }
        public decimal FGQty { get; set; }
        public decimal DiffHours { get; set; }
        public decimal PcsPerHr { get; set; }
        public int Cnt { get; set; }
        public double Percent { get; set; }
	}
}
