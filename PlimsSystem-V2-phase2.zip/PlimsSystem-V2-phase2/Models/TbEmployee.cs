﻿namespace Plims.Models
{
    public class TbEmployee
    {
    }
}
